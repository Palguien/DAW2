"use-strict"
//document.getElementById("formulario-enviar").addEventListener("click", tablero);
document.getElementById("a").addEventListener("click", cosa);

function cosa() {
    
    let minas=document.getElementById("minas").value;
    let lado=document.getElementById("casillas").value;
    let casillas=lado*lado;
    let arrayTablero = generarBombas(casillas,minas);

    console.log(minas);
    console.log(lado);

    let cont = 0;

    for (let index = 0; index < lado; index++) {
        let tr = document.createElement("tr");
        for (let index2 = 0; index2 < lado; index2++) {
            let td = document.createElement("td");
            if(arrayTablero[cont]=='B'){
                td.setAttribute("class","bomba");
            }else{
                td.setAttribute("class","vacio");
            }
            tr.appendChild(td);
            cont++;
        }
        table.appendChild(tr);
    }
    let table = document.getElementById("tablero-contenedor");
}


function generarBombas(casillas, minas) {
    if(minas>casillas){
        minas = casillas;
    }
    let array = [];
    for (let index = 0; index < casillas; index++) {
        array.push('V');
    }
    for (let index = 0; index < casillas; index++) {
        console.log("aaa");
        let num = parseInt(Math.random*casillas);
        if(array[num] == 'V'){
            array[num] == 'B';
        }else{
            //index--;
        }
        
    }
    return array;
}